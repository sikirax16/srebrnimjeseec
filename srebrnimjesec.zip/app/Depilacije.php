<?php
/**
 * Created by PhpStorm.
 * User: Marino
 * Date: 21.6.2017.
 * Time: 15:40
 */

namespace App;

use Illuminate\Database\Eloquent\Model;

class Depilacije extends Model
{
    public $timestamps = false;
    protected $table = 'depilacija';
}