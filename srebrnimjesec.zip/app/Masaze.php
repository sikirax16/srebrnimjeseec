<?php
/**
 * Created by PhpStorm.
 * User: Marino
 * Date: 21.6.2017.
 * Time: 14:32
 */

namespace App;


use Illuminate\Database\Eloquent\Model;

class Masaze extends Model
{
    public $timestamps = false;
    protected $table = 'masaza';
}