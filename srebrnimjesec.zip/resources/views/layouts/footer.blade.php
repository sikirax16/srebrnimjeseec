<footer>
    <div class="container">
        <div class="row social-buttons">
            <div class="col-md-4">
                <i>Kontakt: </i>
            </div>
            <div class="col-md-4">
                <a href="https://web.facebook.com/sreberni.mjesec/?fref=ts"><i><img src="images/facebook.png" /> Srebrni Mjesec</i></a>
                <p><i class="glyphicon glyphicon-earphone"> 052/418-900</i></p>
            </div>
            <div class="col-md-4">
                <a href="https://web.facebook.com/Frizerski-Salon-5-Stars-157392858128345/?ref=ts&fref=ts&_rdc=1&_rdr"><i><img src="images/facebook.png" /> 5 Stars</i></a>
                <p><i class="glyphicon glyphicon-earphone"> 052/210-244</i></p>
            </div>
        </div>
    </div>
</footer>