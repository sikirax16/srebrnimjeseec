<nav class="navbar navbar-fixed-top navbar-custom">
    <div class="container">

        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nSM">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="/" class="navbar-brand brand-style">
                <img g src="/images/logo4.png">
            </a>
        </div>

        <div id="nSM" class="collapse navbar-collapse navbar-right">
            <ul class="nav navbar-nav">
                <li><a href="/">Naslovna</a></li>
                {{--<li><a href="5stars">5 Stars</a></li>--}}
                <li><a href="galerija">Galerija</a></li>
                <li><a href="cjenik">Cjenik</a></li>
            </ul>
        </div>
    </div>
</nav>

{{--<nav class="navbar navbar-fixed-top navbar-custom">--}}
    {{--<div class="container">--}}

        {{--<div class="navbar-header">--}}
            {{--<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nSM">--}}
                {{--<span class="icon-bar"></span>--}}
                {{--<span class="icon-bar"></span>--}}
                {{--<span class="icon-bar"></span>--}}
            {{--</button>--}}
            {{--<div class="brand-centered">--}}
                {{--<a href="/" class="navbar-brand">--}}
                    {{--<img src="/images/logo4.png">--}}
                {{--</a>--}}
            {{--</div>--}}
        {{--</div>--}}

        {{--<div id="nSM" class="collapse navbar-collapse">--}}
            {{--<ul class="nav navbar-nav navbar-left">--}}
                {{--<li><a href="/">Naslovna</a></li>--}}
                {{--<li><a href="5stars">5 Stars</a></li>--}}
            {{--</ul>--}}
            {{--<ul class="nav navbar-nav navbar-right">--}}
                {{--<li><a href="galerija">Galerija</a></li>--}}
                {{--<li><a href="cjenik">Cjenik</a></li>--}}
            {{--</ul>--}}
        {{--</div>--}}
    {{--</div>--}}
{{--</nav>--}}