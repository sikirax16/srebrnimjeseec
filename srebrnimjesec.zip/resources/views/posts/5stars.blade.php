@extends('layouts.master')

@section('content')


<div class="sadrzaj">
    <h1>5stars</h1>
</div>

@endsection