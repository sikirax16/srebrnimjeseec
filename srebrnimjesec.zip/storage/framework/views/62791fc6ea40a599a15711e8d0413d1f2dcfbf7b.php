<?php $__env->startSection('content'); ?>
    <section class="container">
        <p>dsfisbvkj eiodncwie uhnos ehuaip doaks ndk</p>
        <img src="images/oko.jpg" alt="images/okso.jpg" height="400" width="300" />
    </section>


    
        
        
        
        
        

        
        
        
            
        

        
            
        


        
        
    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>