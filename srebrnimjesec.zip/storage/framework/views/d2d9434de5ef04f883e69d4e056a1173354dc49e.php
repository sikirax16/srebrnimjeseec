<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Diplomski rad</title>

        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="css/bootstrap/bootstrap.min.css" type="text/css">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Theme CSS -->
        <link href="css/nav_footer.css" rel="stylesheet">



    </head>
    <body>

        <?php echo $__env->make('layouts.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="container">

            <?php echo $__env->yieldContent('content'); ?>

        </div>

        <div class="container">
            <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>


        <!-- Plugin JavaScript -->
        <script src="js/jquery.easing.min.js" integrity="sha384-mE6eXfrb8jxl0rzJDBRanYqgBxtJ6Unn4/1F7q4xRRyIw7Vdg9jP4ycT7x1iVsgb" crossorigin="anonymous"></script>

        <!-- Theme JavaScript -->
        <script src="js/agency.min.js"></script>

        <!-- Bootstrap Core JavaScript -->
        <script src="/public/js/bootstrap.min.js"></script>
    </body>
</html>
