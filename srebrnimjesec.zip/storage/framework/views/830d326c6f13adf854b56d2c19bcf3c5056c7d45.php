<?php $__env->startSection('content'); ?>
    <div class="sadrzaj">

        <h1>cjenik</h1>
        
        <?php if(!$haircut->isEmpty()): ?>
            <div class="container-fluid cjenik">

                <div class="row">
                    <div class="col-xs-2 dio">
                        <p>Cijene frizura</p>
                    </div>
                    <div class="col-xs-10 naziv">

                        <table class="table table-responsive">
                            <tbody>
                            <?php ($counter = 0); ?>
                            <?php $__currentLoopData = $haircut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($counter%2==0): ?>
                                    <tr class="cjenik-row">
                                    <?php ($counter++); ?>
                                <?php else: ?>
                                    <tr>
                                    <?php ($counter++); ?>
                                <?php endif; ?>
                                    <td><p class="text-left"><?php echo e($price->naziv); ?></p></td>
                                    <td><p class="text-right"><?php echo e($price->cijena); ?> kn</p></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        
        <?php if(!$massage->isEmpty()): ?>
        <div class="container-fluid cjenik">
            <div class="row">
                <div class="col-xs-2 dio">
                    <p>Cijene masaza</p>
                </div>
                <div class="col-xs-10 naziv">

                    <table class="table table-responsive">
                        <tbody>
                        <?php ($counter = 0); ?>
                            <?php $__currentLoopData = $massage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($counter%2==0): ?>
                                    <tr class="cjenik-row">
                                    <?php ($counter++); ?>
                                <?php else: ?>
                                    <tr>
                                    <?php ($counter++); ?>
                                <?php endif; ?>
                                    <td><p class="text-left"><?php echo e($price->naziv); ?></p></td>
                                    <td><p><?php echo e($price->trajanje); ?> min</p></td>
                                    <td><p class="text-right"><?php echo e($price->cijena); ?> kn</p></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if(!$depilation->isEmpty()): ?>
        <div class="container-fluid cjenik">
            <div class="row">
                <div class="col-xs-2 dio">
                    <p>Cijene depilacija</p>
                </div>
                <div class="col-xs-10 naziv">

                    <table class="table table-responsive">
                        <tbody>
                        <?php ($counter = 0); ?>
                            <?php $__currentLoopData = $depilation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($counter%2==0): ?>
                                    <tr class="cjenik-row">
                                    <?php ($counter++); ?>
                                <?php else: ?>
                                    <tr>
                                    <?php ($counter++); ?>
                                <?php endif; ?>

                                <tr class="cjenik-row">
                                    <td><p class="text-left"><?php echo e($price->naziv); ?></p></td>
                                    <td><p class="text-right"><?php echo e($price->cijena); ?> kn</p></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        
        <?php if(!$oglasi->isEmpty()): ?>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h1>Oglasi</h1>
                    </div>
                    <div class="col-xs-12">
                        <?php $__currentLoopData = $oglasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oglas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row oglas">
                                <?php if($oglas->original_filename!=""): ?>
                                    <div class="col-xs-6">
                                        <img src="oglasi\<?php echo e($oglas->original_filename); ?>" alt="<?php echo e($oglas->id); ?>">
                                    </div>
                                    <div class="col-xs-6">
                                        <h1><?php echo e($oglas->naslov); ?></h1>
                                        <p><?php echo e($oglas->opis); ?></p>
                                        <p><?php echo e($oglas->kontakt); ?></p>
                                    </div>
                                <?php else: ?>
                                    <div class="col-xs-12">
                                        <h1><?php echo e($oglas->naslov); ?></h1>
                                        <p><?php echo e($oglas->opis); ?></p>
                                        <p><?php echo e($oglas->kontakt); ?></p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>