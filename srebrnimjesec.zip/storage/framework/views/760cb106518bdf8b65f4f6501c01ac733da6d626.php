<?php $__env->startSection('content'); ?>
    <div class="sadrzaj">
        <h1>galerija</h1>
        <div class="container-fluid gallery-container">

            <div class="tz-gallery">

                <div class="row">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm-4 col-md-3">
                            <a class="lightbox" href="frizure\<?php echo e($image->original_filename); ?>">
                                <img src="frizure\<?php echo e($image->original_filename); ?>" alt="<?php echo e($image->id); ?>">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>